<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CommandController extends Controller
{
    public function store(){

    }

    public function update(){

    }

    public function delete(){

    }
}
